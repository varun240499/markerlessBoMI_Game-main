from keyboard import Keyboard

 
kb = Thread(target=Keyboard)
kb.start()